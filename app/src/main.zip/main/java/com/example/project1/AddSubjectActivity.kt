package com.example.project1

import android.app.TimePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AddSubjectActivity : AppCompatActivity() {

    private lateinit var etSubjectName: EditText
    private lateinit var btnMon: ToggleButton
    private lateinit var btnTue: ToggleButton
    private lateinit var btnWed: ToggleButton
    private lateinit var btnThu: ToggleButton
    private lateinit var btnFri: ToggleButton

    private lateinit var btnStartTime: Button
    private lateinit var btnEndTime: Button

    private lateinit var btnColorRed: Button
    private lateinit var btnColorBlue: Button
    private lateinit var btnColorGreen: Button

    private lateinit var btnSave: Button

    private var selectedDay: Int = -1
    private var startHour = 0
    private var startMinute = 0
    private var endHour = 0
    private var endMinute = 0
    private var selectedColor = Color.LTGRAY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_subject)

        etSubjectName = findViewById(R.id.etSubjectName)
        btnMon = findViewById(R.id.btnMon)
        btnTue = findViewById(R.id.btnTue)
        btnWed = findViewById(R.id.btnWed)
        btnThu = findViewById(R.id.btnThu)
        btnFri = findViewById(R.id.btnFri)

        btnStartTime = findViewById(R.id.btnStartTime)
        btnEndTime = findViewById(R.id.btnEndTime)

        btnColorRed = findViewById(R.id.btnColorRed)
        btnColorBlue = findViewById(R.id.btnColorBlue)
        btnColorGreen = findViewById(R.id.btnColorGreen)

        btnSave = findViewById(R.id.btnSave)

        // 요일 선택
        val dayButtons = listOf(btnMon, btnTue, btnWed, btnThu, btnFri)
        dayButtons.forEachIndexed { index, button ->
            button.setOnCheckedChangeListener { _, isChecked ->
                if (isChecked) {
                    // 나머지 요일 해제
                    dayButtons.filterNot { it == button }.forEach { it.isChecked = false }
                    selectedDay = index + 1 // 월=1, 화=2...
                } else {
                    if (selectedDay == index + 1) selectedDay = -1
                }
            }
        }

        // 시간 선택
        btnStartTime.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                startHour = hour
                startMinute = minute
                btnStartTime.text = String.format("시작 %02d:%02d", hour, minute)
            }, 9, 0, true).show()
        }

        btnEndTime.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                endHour = hour
                endMinute = minute
                btnEndTime.text = String.format("종료 %02d:%02d", hour, minute)
            }, 10, 0, true).show()
        }

        // 색상 선택
        btnColorRed.setOnClickListener { selectedColor = Color.parseColor("#F44336") }
        btnColorBlue.setOnClickListener { selectedColor = Color.parseColor("#2196F3") }
        btnColorGreen.setOnClickListener { selectedColor = Color.parseColor("#4CAF50") }

        // 저장 버튼
        btnSave.setOnClickListener {
            val name = etSubjectName.text.toString()
            if (name.isBlank() || selectedDay == -1) {
                Toast.makeText(this, "모든 항목을 입력하세요!", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val subject = Subject(
                name = name,
                dayOfWeek = selectedDay,
                startHour = startHour,
                startMinute = startMinute,
                endHour = endHour,
                endMinute = endMinute,
                color = selectedColor
            )

            val resultIntent = Intent().apply {
                putExtra("subject", subject)
            }

            setResult(RESULT_OK, resultIntent)
            finish()
        }
    }
}
