package com.example.project1

import android.app.Activity
import android.app.TimePickerDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

import kotlin.math.max

class AddSubjectActivity : AppCompatActivity() {

    private val selectedDays = mutableListOf<Int>()

    private var selectedColor: Int = 0xFFFF3B30.toInt()
    private lateinit var etSubjectName: EditText
    private lateinit var tvStartTime: TextView
    private lateinit var tvEndTime: TextView
    private var selectedStartHour = 9
    private var selectedStartMinute = 0
    private var selectedEndHour = 10
    private var selectedEndMinute = 0
    private lateinit var allDayButtons: List<TextView>


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_subject)

        etSubjectName = findViewById(R.id.etSubjectName)
        tvStartTime = findViewById(R.id.tvStartTime)
        tvEndTime = findViewById(R.id.tvEndTime)

        tvStartTime.text = String.format("%02d:%02d", selectedStartHour, selectedStartMinute)
        tvEndTime.text = String.format("%02d:%02d", selectedEndHour, selectedEndMinute)

        // R.id.btnSaveSubject ID 사용 (activity_add_subject.xml에서 해당 ID가 맞는지 최종 확인)
        val btnSave = findViewById<TextView>(R.id.btnSaveSubject)

        allDayButtons = listOf(
            findViewById(R.id.btnMon),
            findViewById(R.id.btnTue),
            findViewById(R.id.btnWed),
            findViewById(R.id.btnThu),
            findViewById(R.id.btnFri)
        )

        // 요일 버튼 클릭 리스너: 선택된 요일 목록 업데이트 및 배경색 변경
        allDayButtons.forEachIndexed { index, button ->
            button.setOnClickListener {
                if (selectedDays.contains(index)) { // 이미 선택된 요일이면 제거
                    selectedDays.remove(index)
                    button.backgroundTintList = ColorStateList.valueOf(0xFF444444.toInt()) // 비활성화 색상
                } else { // 선택되지 않은 요일이면 추가
                    selectedDays.add(index)
                    button.backgroundTintList = ColorStateList.valueOf(0xFF8888FF.toInt()) // 활성화 색상
                }
                Log.d("AddSubjectActivity", "Selected Days: $selectedDays") // ✨ Log 태그 통일
            }
        }

        // 시작 시간 선택 다이얼로그
        tvStartTime.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                selectedStartHour = hour
                selectedStartMinute = minute
                tvStartTime.text = String.format("%02d:%02d", hour, minute)
            }, selectedStartHour, selectedStartMinute, false).show()
        }

        // 종료 시간 선택 다이얼로그
        tvEndTime.setOnClickListener {
            TimePickerDialog(this, { _, hour, minute ->
                selectedEndHour = hour
                selectedEndMinute = minute
                tvEndTime.text = String.format("%02d:%02d", hour, minute)
            }, selectedEndHour, selectedEndMinute, false).show()
        }

        // 색상 선택 로직
        val colorViews = listOf(
            findViewById<View>(R.id.colorRed),
            findViewById<View>(R.id.colorOrange),
            findViewById<View>(R.id.colorYellow),
            findViewById<View>(R.id.colorGreen),
            findViewById<View>(R.id.colorSky),
            findViewById<View>(R.id.colorBlue),
            findViewById<View>(R.id.colorPurple)
        )
        val colorValues = listOf(
            0xFFFF3B30.toInt(), 0xFFFF922C.toInt(), 0xFFFFFF1D.toInt(),
            0xFF1CD282.toInt(), 0xFF20DEF0.toInt(), 0xFF415AFE.toInt(), 0xFFBD59FF.toInt()
        )

        // 초기 선택된 색상 표시 (기본 빨간색)
        colorViews[0].background = resources.getDrawable(R.drawable.bg_color_circle_selected, null)
        selectedColor = colorValues[0]

        colorViews.forEachIndexed { i, view ->
            view.setOnClickListener {
                // 이전에 선택된 색상 뷰의 선택 표시 제거
                val prevSelectedColorView = colorViews.find {
                    it.background is GradientDrawable || it.background == resources.getDrawable(R.drawable.bg_color_circle_selected, null)
                }
                prevSelectedColorView?.background = null // 배경 제거 (선택 해제)

                // 현재 클릭된 색상 뷰를 선택 상태로 변경
                selectedColor = colorValues[i]
                view.background = resources.getDrawable(R.drawable.bg_color_circle_selected, null)

                Log.d("AddSubjectActivity", "Selected Color: ${String.format("#%06X", (selectedColor and 0xFFFFFF))}") // ✨ Log 태그 통일
            }
        }

        // 뒤로가기 버튼
        val btnBack = findViewById<ImageView>(R.id.btnBack)
        btnBack.setOnClickListener {
            finish()
        }

        // 과목 저장 버튼 클릭 리스너
        btnSave.setOnClickListener {
            val name = etSubjectName.text.toString().trim()

            // 입력 유효성 검사
            if (name.isEmpty()) {
                Toast.makeText(this, "과목명을 입력해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (selectedDays.isEmpty()) {
                Toast.makeText(this, "요일을 선택해주세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (selectedStartHour * 60 + selectedStartMinute >= selectedEndHour * 60 + selectedEndMinute) {
                Toast.makeText(this, "시작 시간이 종료 시간보다 빠르거나 같을 수 없습니다.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Subject 객체 생성
            val subject = Subject(
                name = name,
                days = selectedDays.toList(), // 🚨 selectedDays 리스트를 Subject의 days 파라미터로 전달
                color = selectedColor,
                startHour = selectedStartHour,
                startMinute = selectedStartMinute,
                endHour = selectedEndHour,
                endMinute = selectedEndMinute)

            // 결과 인텐트에 Subject 객체 담아 MainActivity로 전달
            val result = Intent().apply {
                putExtra("subject", subject)
            }
            setResult(Activity.RESULT_OK, result)
            finish() // 현재 액티비티 종료

            Log.d("AddSubjectActivity", "과목 저장: name=$name, days=$selectedDays, start=$selectedStartHour:$selectedStartMinute, end=$selectedEndHour:$selectedEndMinute, color=${String.format("#%06X", (selectedColor and 0xFFFFFF))}") // ✨ Log 태그 통일
        }
    }
}