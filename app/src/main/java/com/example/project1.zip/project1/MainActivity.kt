package com.example.project1

import android.app.Activity
import android.content.Intent
import android.content.res.Resources
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewTreeObserver
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.ceil
import kotlin.math.max


class MainActivity : AppCompatActivity() {

    private lateinit var timetableGrid: GridLayout
    private val subjectList = mutableListOf<Subject>()
    private lateinit var timeLabelsLayout: LinearLayout

    private val addSubjectLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK) {
                val subject = getSubjectFromResult(result.data)
                Log.d("MainActivity", "수신된 과목: $subject") // 태그 변경
                subject?.let {
                    subjectList.add(it)
                    drawAllSubjects()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        timetableGrid = findViewById(R.id.timetableGrid)
        timeLabelsLayout = findViewById(R.id.timeLabels)

        val btnAdd = findViewById<ImageView>(R.id.btnAdd)
        btnAdd.setOnClickListener {
            val intent = Intent(this, AddSubjectActivity::class.java)
            addSubjectLauncher.launch(intent)
        }

        loadSubjects()

        // ViewTreeObserver를 사용하여 timeLabelsLayout의 높이가 측정된 후 시간표를 그립니다.
        timeLabelsLayout.viewTreeObserver.addOnGlobalLayoutListener(object : ViewTreeObserver.OnGlobalLayoutListener {
            override fun onGlobalLayout() {
                timeLabelsLayout.viewTreeObserver.removeOnGlobalLayoutListener(this)
                Log.d("MainActivity", "onGlobalLayout: timeLabelsLayout 높이 측정 완료. 높이: ${timeLabelsLayout.height}") // 태그 변경
                drawAllSubjects()
            }
        })
    }

    private fun getSubjectFromResult(data: Intent?): Subject? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            data?.getSerializableExtra("subject", Subject::class.java)
        } else {
            @Suppress("DEPRECATION")
            data?.getSerializableExtra("subject") as? Subject
        }
    }

    private fun dpToPx(dp: Int): Int {
        val scale = resources.displayMetrics.density
        return (dp * scale + 0.5f).toInt()
    }

    private fun loadSubjects() {
        // TODO: 여기에 SharedPreferences, Room DB 등에서 저장된 과목 리스트를 로드하는 로직 구현
        // 현재는 테스트용 예시 과목 (필요시 주석 해제하여 사용)
        // subjectList.add(Subject("모바일앱프로그래밍", listOf(0), 9, 0, 10, 0, Color.parseColor("#FF6666"))) // 월 9:00~10:00
        // subjectList.add(Subject("데이터베이스", listOf(2), 11, 0, 12, 30, Color.parseColor("#66CC66"))) // 수 11:00~12:30
        // subjectList.add(Subject("컴퓨터구조", listOf(4), 14, 0, 16, 0, Color.parseColor("#6666CC"))) // 금 14:00~16:00
    }

    private fun drawAllSubjects() {
        timetableGrid.removeAllViews()

        val totalTimeLabelsHeight = timeLabelsLayout.height
        val hourLabelCount = timeLabelsLayout.childCount
        Log.d("MainActivity", "drawAllSubjects - totalTimeLabelsHeight: $totalTimeLabelsHeight, hourLabelCount: $hourLabelCount") // 태그 변경

        val heightPerHourPx = if (hourLabelCount > 0 && totalTimeLabelsHeight > 0) {
            totalTimeLabelsHeight / hourLabelCount
        } else {
            dpToPx(80) // Fallback 값
        }
        Log.d("MainActivity", "drawAllSubjects - Calculated heightPerHourPx: $heightPerHourPx") // 태그 변경

        val heightPer15MinPx = heightPerHourPx / 4
        Log.d("MainActivity", "drawAllSubjects - Calculated heightPer15MinPx: $heightPer15MinPx") // 태그 변경

        for (subject in subjectList) {
            addSubjectCellsForSubject(subject, heightPer15MinPx)
        }
    }

    private fun addSubjectCellsForSubject(subject: Subject, heightPer15MinPx: Int) {
        val startHourOffset = 9 // 시간표 시작 시간 (9시가 0행 기준)
        val startTotalMin = subject.startHour * 60 + subject.startMinute
        val endTotalMin = subject.endHour * 60 + subject.endMinute
        val totalMinutes = endTotalMin - startTotalMin

        // 행 계산: (과목 시작 총 분 - 시간표 시작 총 분)을 15분으로 나눔.
        // 이렇게 하면 9시 0분은 0행, 9시 15분은 1행이 됩니다.
        val row = (startTotalMin - (startHourOffset * 60)) / 15
        val rowSpan = ceil(totalMinutes / 15.0).toInt().coerceAtLeast(1)

        val displayMetrics = Resources.getSystem().displayMetrics
        val screenWidth = displayMetrics.widthPixels

        val horizontalPaddingOfWrapperPx = dpToPx(12) * 2
        val timeLabelColumnWidthPx = dpToPx(40)

        val actualTimetableGridWidth = screenWidth - horizontalPaddingOfWrapperPx - timeLabelColumnWidthPx
        val cellWidth = actualTimetableGridWidth / 5

        Log.d("MainActivity", "addSubjectCellsForSubject - screenWidth: $screenWidth, padding: $horizontalPaddingOfWrapperPx, timeLabelWidth: $timeLabelColumnWidthPx, actualGridWidth: $actualTimetableGridWidth, cellWidth: $cellWidth") // 태그 변경

        for (dayIndex in subject.days) {
            // ✨ 이 부분이 핵심: dayIndex는 이미 0(월)부터 4(금)까지 올바르게 오므로,
            // 별도의 변환 없이 그대로 column으로 사용해야 합니다.
            val column = dayIndex
            Log.d("MainActivity", "Adding cell for subject: ${subject.name}, dayIndex: $dayIndex, calculated_column: $column, row: $row, rowSpan: $rowSpan") // 태그 변경

            val inflater = LayoutInflater.from(this)
            val cell = inflater.inflate(R.layout.item_timetable_cell, timetableGrid, false) as TextView
            cell.text = subject.name
            cell.setBackgroundColor(subject.color)
            cell.textAlignment = View.TEXT_ALIGNMENT_CENTER
            cell.setTextColor(Color.WHITE)
            cell.setTextSize(10f)

            val params = GridLayout.LayoutParams(
                GridLayout.spec(row, rowSpan),
                GridLayout.spec(column)
            ).apply {
                width = cellWidth
                height = rowSpan * heightPer15MinPx
                setMargins(dpToPx(6), dpToPx(1) + dpToPx(5), dpToPx(1), dpToPx(1))
                setGravity(Gravity.FILL)
            }

            cell.layoutParams = params
            timetableGrid.addView(cell)

            Log.d("MainActivity", "셀 추가 완료: 과목=${subject.name}, 요일=${dayIndex}, row=$row, rowSpan=$rowSpan, column=$column, final_width=${params.width}, final_height=${params.height}") // 태그 변경
        }
    }
}