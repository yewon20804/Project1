package com.example.project1

data class TimetableCell(
    val name: String? = null,
    val color: Int? = null
)