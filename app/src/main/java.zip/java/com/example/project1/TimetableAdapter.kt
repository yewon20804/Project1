package com.example.project1

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.LinearLayout
import androidx.recyclerview.widget.RecyclerView
import com.example.project1.R

class TimetableAdapter(
    private val subjectList: List<Subject>
) : RecyclerView.Adapter<TimetableAdapter.TimetableViewHolder>() {

    class TimetableViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvSubjectName: TextView = itemView.findViewById(R.id.tvSubjectName)
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val backgroundLayout: LinearLayout = itemView.findViewById(R.id.item_background)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimetableViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_timetable, parent, false)
        return TimetableViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimetableViewHolder, position: Int) {
        val subject = subjectList[position]
        holder.tvSubjectName.text = subject.name
        holder.tvTime.text = "${formatTime(subject.startHour, subject.startMinute)} ~ ${formatTime(subject.endHour, subject.endMinute)}"
        holder.backgroundLayout.setBackgroundColor(subject.color)
    }

    override fun getItemCount(): Int = subjectList.size

    private fun formatTime(hour: Int, minute: Int): String {
        val h = if (hour < 10) "0$hour" else "$hour"
        val m = if (minute < 10) "0$minute" else "$minute"
        return "$h:$m"
    }
}